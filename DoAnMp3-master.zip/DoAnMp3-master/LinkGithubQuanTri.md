App này do bạn Vũ Đình Khoa chịu trách nhiệm.
https://github.com/khoavd001/manageapp
